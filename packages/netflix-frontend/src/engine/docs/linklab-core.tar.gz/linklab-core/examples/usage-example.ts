// examples/usage-example.ts

/**
 * Complete usage examples for LinkLab Core
 */

import { Engine, GraphBuilder, templates } from '../index'

// ==================== EXAMPLE 1: Simple Pathfinding ====================

async function example1_SimplePathfinding() {
  console.log('\n=== Example 1: Simple Pathfinding ===\n')

  // Create a simple graph
  const graph = new GraphBuilder()
    .addEntity('Stations')
    .connect('Stations', 'Stations', {
      through: 'line-1',
      weight: 2
    })
    .build()

  // Add some manual relations
  graph.relations.push(
    { name: 'A-B', fromEntity: 'Station-A', toEntity: 'Station-B', via: 'line-1', weight: 2 },
    { name: 'B-C', fromEntity: 'Station-B', toEntity: 'Station-C', via: 'line-1', weight: 3 },
    { name: 'C-D', fromEntity: 'Station-C', toEntity: 'Station-D', via: 'line-1', weight: 2 }
  )

  // Create pathfinding engine
  const engine = Engine.forPathfinding(graph, {
    from: 'Station-A',
    to: 'Station-D',
    maxPaths: 5
  })

  // Run
  const results = await engine.run()

  if (results[0].path) {
    console.log('Path found:')
    console.log(`  Nodes: ${results[0].path.nodes.join(' → ')}`)
    console.log(`  Total weight: ${results[0].path.totalWeight}`)
  }
}

// ==================== EXAMPLE 2: Using Templates ====================

async function example2_UsingTemplates() {
  console.log('\n=== Example 2: Using Templates ===\n')

  // Create a recommendation graph using template
  const graph = templates.recommendations({
    entities: ['Users', 'Products', 'Categories'],
    userLikes: 'user_products',
    productCategories: 'product_categories'
  })

  console.log('Created recommendation graph with:')
  console.log(`  ${graph.relations.length} relations`)

  // Use it for pathfinding
  const engine = Engine.forPathfinding(graph, {
    from: 'User-123',
    to: 'Product-456'
  })

  console.log('\nEngine created and ready to find paths.')
}

// ==================== EXAMPLE 3: Org Chart ====================

async function example3_OrgChart() {
  console.log('\n=== Example 3: Org Chart ===\n')

  // Create org chart graph
  const graph = templates.orgChart({
    departments: true
  })

  // Add some employees
  graph.relations.push(
    { name: 'john-sarah', fromEntity: 'Employee-john', toEntity: 'Employee-sarah', via: 'reports_to', weight: 1 },
    { name: 'sarah-ceo', fromEntity: 'Employee-sarah', toEntity: 'Employee-ceo', via: 'reports_to', weight: 1 }
  )

  // Find chain of command
  const engine = Engine.forPathfinding(graph, {
    from: 'Employee-john',
    to: 'Employee-ceo'
  })

  const results = await engine.run()

  if (results[0].path) {
    console.log('Chain of command:')
    console.log(`  ${results[0].path.nodes.join(' → ')}`)
    console.log(`  ${results[0].path.nodes.length - 1} levels`)
  }
}

// ==================== EXAMPLE 4: Musicians Sampling ====================

async function example4_Musicians() {
  console.log('\n=== Example 4: Musicians Sampling ===\n')

  // Create musicians graph
  const graph = templates.musicians({
    includeGenres: true
  })

  // Add some sample data
  graph.relations.push(
    // Manu Dibango created "Soul Makossa"
    { name: 'manu-soul', fromEntity: 'Artist-manu-dibango', toEntity: 'Track-soul-makossa', via: 'created', weight: 2 },
    
    // Michael Jackson created "Wanna Be Startin'"
    { name: 'mj-wanna', fromEntity: 'Artist-michael-jackson', toEntity: 'Track-wanna-be-startin', via: 'created', weight: 2 },
    
    // "Wanna Be Startin'" samples "Soul Makossa"
    { name: 'wanna-samples-soul', fromEntity: 'Track-wanna-be-startin', toEntity: 'Track-soul-makossa', via: 'samples', weight: 5 },
    
    // Will Smith created "Gettin' Jiggy"
    { name: 'will-jiggy', fromEntity: 'Artist-will-smith', toEntity: 'Track-gettin-jiggy', via: 'created', weight: 2 },
    
    // "Gettin' Jiggy" samples "Wanna Be Startin'"
    { name: 'jiggy-samples-wanna', fromEntity: 'Track-gettin-jiggy', toEntity: 'Track-wanna-be-startin', via: 'samples', weight: 5 }
  )

  // Find connection: Will Smith → Manu Dibango
  const engine = Engine.forPathfinding(graph, {
    from: 'Artist-will-smith',
    to: 'Artist-manu-dibango',
    maxPaths: 3
  })

  const results = await engine.run()

  if (results[0].path) {
    console.log('Connection found:')
    console.log(`  ${results[0].path.nodes.join(' → ')}`)
    console.log(`  Via: ${results[0].path.relations.map(r => r.via).join(', ')}`)
  }
}

// ==================== EXAMPLE 5: Custom Builder ====================

async function example5_CustomBuilder() {
  console.log('\n=== Example 5: Custom Builder ===\n')

  // Build a custom graph from scratch
  const graph = new GraphBuilder()
    .addEntity('Movies')
    .addEntity('Actors')
    .addEntity('Directors')
    .connect('Directors', 'Movies', {
      through: 'directed',
      weight: 5
    })
    .connect('Actors', 'Movies', {
      through: 'acted_in',
      weight: 3
    })
    .connect('Movies', 'Actors', {
      through: 'featured',
      weight: 3
    })
    .build()

  console.log('Created cinema graph with:')
  console.log(`  ${graph.relations.length} relations`)
  console.log(`  3 entity types`)
}

// ==================== RUN ALL EXAMPLES ====================

async function runAll() {
  await example1_SimplePathfinding()
  await example2_UsingTemplates()
  await example3_OrgChart()
  await example4_Musicians()
  await example5_CustomBuilder()

  console.log('\n=== All examples completed ===\n')
}

// Run if called directly
if (require.main === module) {
  runAll().catch(console.error)
}

export {
  example1_SimplePathfinding,
  example2_UsingTemplates,
  example3_OrgChart,
  example4_Musicians,
  example5_CustomBuilder
}
